import os
import datetime

def run_system_audit():
    print("========================================")
    print("   SANGEETHA  - SECURITY AUDIT      ")
    print("========================================")
    
    # Get current date
    now = datetime.datetime.now()
    print(f"Audit Started: {now}")
    
    # Check OS Info
    print("\n[1] System Information:")
    os.system("uname -a")
    
    # Check Open Ports
    print("\n[2] Checking Network Services:")
    os.system("netstat -tuln")
    
    print("\nAudit Complete. Generating HTML Report...")

if _name_ == "_main_":
    run_system_audit()