#!/bin/bash

echo "=== AUTOMATED BACKUP SCRIPT ==="

read -p "Enter directory to backup: " SOURCE
read -p "Enter backup destination: " DEST

if [ ! -d "$SOURCE" ]; then
     echo "Error: Source directory $SOURCE  does not exist!"
     exit 1
fi

mkdir -p "$DEST"

echo "Backup Type:"
echo "1. Simple copy (cp)"
echo "2. Compressed archive (tar.gz)"
read -p "Enter choice: " CHOICE

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
START_TIME=$(date +%s)

if [ "$CHOICE" -eq 1 ]; then
     BACKUP_NAME="backup_$TIMESTAMP"
     cp -r "$SOURCE" "$DEST/$BACKUP_NAME"
else 
     BACKUP_NAME="backup_$TIMESTAMP.tar.gz"
     tar -czf "$DEST/$BACKUP_NAME" "$SOURCE"
fi

if [ $? -eq 0 ];then
   END_TIME=$(date +%s)
   DURATION=$((END_TIME - START_TIME))
   SIZE=$(du -sh  "$DEST/$BACKUP_NAME" | cut -f1)

   echo "Backup completed successfully!"
   echo "File: $BACKUP_NAME"
   echo "Location: $DEST"
   echo "Size: $SIZE"
   echo "Time taken: $DURATION seconds"
else
   echo "Backup failed!"
fi
