def check_password_strength(password):
    if len(password) < 8:
        return "Weak (Too short)"
    if any(char.isdigit() for char in password) and any(char.isupper() for char in password):
        return "Strong"
    return "Medium"

pwd = input("Enter password to test: ")
print(f"Strength: {check_password_strength(pwd)}")