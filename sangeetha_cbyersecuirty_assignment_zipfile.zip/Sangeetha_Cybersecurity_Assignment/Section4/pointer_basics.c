#include <stdio.h>

int main() {
    int score = 100;
    int *ptr;
    ptr = &score;

    printf("Cybersecurity Lab - Sangeetha Raj\n");
    printf("Value of score: %d\n", score);
    printf("Memory Address of score: %p\n", &score);
    printf("Pointer ptr stores address: %p\n", ptr);
    printf("Value accessed via pointer: %d\n", *ptr);

    return 0;
}