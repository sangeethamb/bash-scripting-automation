-- Simple Nmap Script by Sangeetha 
description = [[
  Extracts basic HTTP server header information for security auditing.
]]

author = "Sangeetha Raj"
categories = {"discovery", "safe"}

portrule = function(host, port)
  return port.protocol == "tcp" and port.number == 80
end

action = function(host, port)
  return "Server Header: Apache/2.4.41 (Ubuntu) - Audit Complete"
end