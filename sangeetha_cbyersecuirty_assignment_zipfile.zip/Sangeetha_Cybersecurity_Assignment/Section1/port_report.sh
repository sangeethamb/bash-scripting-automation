#!/bin/bash
# Script by Sangeetha 
echo "Starting Port Scan on $1..."
nmap -F $1 > scan_results.txt
echo "Scan complete. Results saved to scan_results.txt"