#include <stdio.h>
#include <string.h>

void secret_function(char *input) {
    char buffer[8]; 
    // This will overflow because we are putting 20 chars into a space for 8
    strcpy(buffer, input); 
    printf("Buffer contains: %s\n", buffer);
}

int main() {
    char large_data[20] = "ATTACK_DATA_1234567";
    printf("Sangeetha Raj - Testing Buffer Overflow...\n");
    secret_function(large_data);
    return 0;
}