#!/bin/bash

# 1. Cpture the argument
LOGFILE=$1

# 2. Check if the argument is empty
if [ -z "$LOGFILE" ]; then
    echo "Usage: $0 logfile"
    exit 1
fi

#3. Check if file exists (Fixed logic)
if [ ! -f "$LOGFILE" ]; then
    echo "Error: File '$LOGFILE'  does not exist!"
   exit 1
fi

echo "====== LOG FILE ANALYSIS ======"
echo "Log File: $LOGFILE"


TOTAL=$(wc -l < "$LOGFILE")
echo "Total Entries: $TOTAL"
echo ""

echo "Unique IP Addresses:"
awk '{print $1}' "$LOGFILE" | sort |
uniq
echo ""

echo "Status Code Summary:"
awk '{print $NF}' "$LOGFILE" | sort | uniq -c | awk '{print $2 ": " $1 " requests"}'
echo ""

echo "Top 3 IP Addresses:"
awk '{print $1}' "$LOGFILE" | sort | uniq -c | sort -nr | head -3 | awk '{print NR ". " $2 " - " $1 " requests"}'
echo ""

echo "Most Frequently Accessed Page:"
awk '{for(i=1;i<=NF;i++) if($i ~ /^\//) print $i}' "$LOGFILE" | sed 's/\"//g' | sort | uniq -c | sort -nr | head -1 | awk '{print $2}'
