===========================================================
      CYBERSECURITY & LINUX ADMINISTRATION LAB REPORT
===========================================================

STUDENT NAME: Sangeetha M B
ROLL NUMBER:  [1AM24MC089]
DATE:         April 6th 2026
ENVIRONMENT:  Kali Linux / VMware Workstation

-----------------------------------------------------------
PROJECT OVERVIEW:
-----------------------------------------------------------
This assignment demonstrates a comprehensive skill set in 
Linux system administration, network security auditing, 
and low-level programming.

-----------------------------------------------------------
FOLDER STRUCTURE & CONTENTS:
-----------------------------------------------------------
Section1: Bash Scripting & Automation
  - port_report.sh (Automated port scanner)
  - scan_results.txt (Output log)
  - section1_commands.txt (Execution history)

Section2: Python Security Tools
  - password_checker.py (Entropy analysis)
  - network_scanner.py (ARP discovery)

Section3: Networking Fundamentals
  - section3_networking.pdf (OSI Model & Connectivity report)

Section4: C Programming & Memory Security
  - pointer_basics.c (Memory manipulation)
  - buffer_test.c (Buffer Overflow demonstration)

Section5: Network Enumeration (Nmap)
  - section5_nmap.pdf (Service & OS detection report)
  - http-server-info.nse (Custom Nmap script)

Section6: Web Security
  - section6_xss.pdf (Web vulnerability analysis)
  - login.html (Secure portal design)

Section7: Security Auditing (Bonus)
  - security_audit.py (Automated system audit)
  - sample_report.html (Generated audit findings)

-----------------------------------------------------------
NOTES:
-----------------------------------------------------------
All tasks were performed in a controlled lab environment. 
The "Segmentation Fault" in Section 4 confirms a successful 
demonstration of memory corruption vulnerabilities.
===========================================================